using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] float normalMovementSpeed = 4f;
    [SerializeField] float sprintMovementSpeed = 5.6f;
    [SerializeField] bool isFlipped = false;
    [SerializeField] PlayerController playerController;

    CharacterController characterController;
    Animator animator;
    //Rigidbody2D rb;

    int animIDWalkingDirection;
    int animIDSprint;
    // Start is called before the first frame update

    private void Awake()
    {
        characterController = GetComponent<CharacterController>();
        playerController = GetComponent<PlayerController>();
        //rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        animIDWalkingDirection = Animator.StringToHash("WalkingDirection");
        animIDSprint = Animator.StringToHash("Sprint");
    }
    void Start()
    {
        

    }

    // Update is called once per frame
    void Update()
    {
        Move();
    }

    private void Move()
    {

        float movementSpeed = normalMovementSpeed;

        Vector3 moveDirection = new Vector3(playerController.move.x, 0, 0);

        if (playerController.sprint)
        {
            movementSpeed = sprintMovementSpeed;
        }


        //Flip the character

        if (moveDirection.x < 0 && !isFlipped)
        {
            isFlipped = !isFlipped;

            Vector3 theScale = transform.localScale;
            theScale.x = theScale.x * -1;
            transform.localScale = theScale;

        }
        else if (moveDirection.x > 0 && isFlipped)
        {
            isFlipped = !isFlipped;

            Vector3 theScale = transform.localScale;
            theScale.x = theScale.x * -1;
            transform.localScale = theScale;
        }



        //
        //rb.velocity = moveDirection * Time.deltaTime * movementSpeed;
        characterController.Move(movementSpeed * Time.deltaTime * moveDirection);





        // setting animation
        animator.SetFloat(animIDWalkingDirection, Mathf.Abs(moveDirection.x));


        if (movementSpeed == sprintMovementSpeed)
        {
            animator.SetBool(animIDSprint, true);
        }
        else
        {
            animator.SetBool(animIDSprint, false);
        }

        //


    }

    private void ShiftToIdle()
    {

    }

    public void LockMovement()
    {
        playerController.interact = false;
        animator.SetFloat(animIDWalkingDirection, 0);
        animator.SetBool(animIDSprint, false);
        this.enabled = false;

    }

    public void UnlockMovement()
    {
        this.enabled = true;
    }
}
