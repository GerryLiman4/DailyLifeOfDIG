using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;

public class Interactable : MonoBehaviour
{
    [SerializeField] GameObject textBubble;

    [SerializeField] float originalScale;

    [SerializeField] GameObject interactKey;

    [SerializeField] List<string> dialogue;

    [SerializeField] int currentDialogue = 0;
    //[SerializeField] TextMeshProUGUI dsa = null;

    [SerializeField] NPCController nPCController;
    [SerializeField] Portal portal;

    [SerializeField]public string objectName = "Default";

    
    [SerializeField] Narrator narrator;

    [SerializeField] bool portalHasDialogue = false;

    






    private void Awake()
    {
        originalScale = transform.localScale.x;
        nPCController = GetComponent<NPCController>();
        portal = GetComponent<Portal>();
        

    }
    // Start is called before the first frame update
    void Start()
    {
        narrator = GameObject.FindObjectOfType<Narrator>();
        interactKey.gameObject.SetActive(false);
        textBubble = GameObject.Find("TextBubble").gameObject;
        

    }

    private void OnEnable()
    {
        interactKey = transform.Find("InteractKey").gameObject;

    }

    private void OnDisable()
    {
        interactKey = null;
        //textBubble = null;
    }

    // Update is called once per frame

    private void LateUpdate()
    {

        if (interactKey == null) return;

        //Vector3 tempScale = interactKey.transform.localScale;
        //interactKey.transform.localScale = new Vector3(originalScale, tempScale.y, tempScale.z);
    }


    public void Interact(Transform playerTransform)
    {
        narrator.AddInteraction(transform);
        
        // check if it is npc, can look at player
        if (nPCController != null)
        {
            if (narrator.currentDay == 1)
            {
                Vector2 direction = playerTransform.position - transform.position;
                if (direction.x > 0)
                {
                    Flip(1);
                }
                else if (direction.x < 0)
                {
                    Flip(-1);
                }
            }
            else if (narrator.currentDay >= 2) {
                dialogue.Clear();
                dialogue.Add(".....");
            }
        }
        else if (portal != null)
        {
            if (!portalHasDialogue)
            {
                gameObject.GetComponent<Collider2D>().enabled = false;
                DisableInteractKey();
                portal.Interact();
                return;
            }
            

            
        }
        //

        AssigningDialogue();
        EnableTextBubble();
        currentDialogue++;
        if (portalHasDialogue)
        {

            if (currentDialogue >= dialogue.Count)
            {
                gameObject.GetComponent<Collider2D>().enabled = false;
                DisableInteractKey();
                portal.Interact();
            }

        }


    }

    private void AssigningDialogue()
    {
        if (currentDialogue >= dialogue.Count)
        {

            textBubble.GetComponent<TextMeshProUGUI>().text = dialogue[dialogue.Count - 1];

        }
        else
        {
            textBubble.GetComponent<TextMeshProUGUI>().text = dialogue[currentDialogue];
        }
        
        
        
        
    }

    public void EnableInteractKey()
    {
        if (portal != null)
        {
            AssigningDialogue();
            EnableTextBubble();

        }
        interactKey.SetActive(true);
    }

    public void DisableInteractKey()
    {
        interactKey.SetActive(false);
    }

    public void EnableTextBubble()
    {
        textBubble.GetComponent<TextMeshProUGUI>().enabled = true; ;

    }


    public void DisableTextBubble()
    {
        textBubble.GetComponent<TextMeshProUGUI>().enabled = false;
    }

    public void CancelInteraction()
    {
        DisableInteractKey();
        DisableTextBubble();

        Flip(originalScale);
    }


    public void Flip(float direction)
    {

        Vector3 theScale = transform.localScale;

        transform.localScale = new Vector3(direction, theScale.y, theScale.z);
    }


}
