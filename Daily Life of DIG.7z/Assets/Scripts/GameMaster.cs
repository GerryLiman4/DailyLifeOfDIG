using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameMaster : MonoBehaviour
{
    [SerializeField]SecondDayScheme[] secondDaySchemes;
    [SerializeField] bool hasSpawned = false;

    [SerializeField] PlayerMovement playerController;

    [SerializeField] float fadeDuration = 2f;

    [SerializeField] GameObject fader = null;
    [SerializeField] Narrator narrator;

    
 
    

   

  
    private void Awake()
    {
        //if (!hasSpawned)
        //{
        //    hasSpawned = true;
        //    DontDestroyOnLoad(gameObject);

        //}

    }
    

    private void Start()
    {
        secondDaySchemes = GameObject.FindObjectsOfType<SecondDayScheme>();
        fader = GameObject.FindGameObjectWithTag("Fader");
        playerController = GameObject.FindObjectOfType<PlayerMovement>();
        narrator = GameObject.FindObjectOfType<Narrator>();

        /*if (onInteraction != null)
        {
            onInteraction.RemoveAllListeners();
        }
            onInteraction.AddListener(addInteraction);
        */
        //Debug.Log("1");

        foreach (SecondDayScheme secondDayScheme in secondDaySchemes) {
            secondDayScheme.CheckIfItIsSecondDay();
        }

        narrator.DoDayPreparation();
        StartCoroutine(FadeIn());
    }
    
    // Start is called before the first frame update


    public IEnumerator RestartScene()
    {

        narrator.AssignDay();
        yield return StartCoroutine(FadeOut());
        if (narrator.currentDay >= 4) {
            yield return SceneManager.LoadSceneAsync(1);
            yield break;
        }
        yield return SceneManager.LoadSceneAsync(SceneManager.GetActiveScene().buildIndex);
        
       


    }

    public IEnumerator FadeOut()
    {
        playerController.LockMovement();
        yield return StartCoroutine(waitForFade(1));

    }




    public IEnumerator FadeIn()
    {

        playerController.LockMovement();
        yield return StartCoroutine(waitForFade(0));



    }



    IEnumerator waitForFade(float target)
    {
        //Mathf.MoveTowards(canvasGroup.alpha, target, Time.deltaTime / time);

        // Debug.Log("2");
        // Fading image
        Image image = fader.GetComponent<Image>();
        var temp = image.color;
        //Debug.Log("alpha image : "+ image.color.a + ", alpha temp : " + temp.a );
        while (!Mathf.Approximately(temp.a, target))
        {
            temp.a = Mathf.MoveTowards(temp.a, target, Time.deltaTime / fadeDuration);
            //Debug.Log(temp.a);
            image.color = temp;
            yield return null;
        }
        // Fading Image

                
        playerController.UnlockMovement();

    }

    

    
}
