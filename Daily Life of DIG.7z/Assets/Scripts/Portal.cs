using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Portal : MonoBehaviour
{

    GameMaster gameMaster;

    private void Awake()
    {
        
    }
    // Start is called before the first frame update

    void Start() {
        gameMaster = GameObject.FindObjectOfType<GameMaster>();
    }


    public void Interact()
    {
        
        StartCoroutine(gameMaster.RestartScene());
    }
}
