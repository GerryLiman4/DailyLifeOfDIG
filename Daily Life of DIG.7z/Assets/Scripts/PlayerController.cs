using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerController : MonoBehaviour
{
    public Vector2 move;
    public bool sprint;

    public bool interact;
    // Start is called before the first frame update
    public void OnMove(InputValue value)
    {
        MoveInput(value.Get<Vector2>());
    }

    private void MoveInput(Vector2 newMoveDirection)
    {
        move = newMoveDirection;
    }

    public void OnSprint(InputValue value)
    {
        SprintInput(value.isPressed);
    }

    private void SprintInput(bool isPressed)
    {
        sprint = isPressed;
    }

    private void OnInteract(InputValue value){
        InteractInput(value.isPressed);
    }

    private void InteractInput(bool isPressed)
    {
       interact = isPressed;
    }
}
