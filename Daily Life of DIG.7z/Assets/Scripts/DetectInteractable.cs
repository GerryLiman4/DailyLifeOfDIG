using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DetectInteractable : MonoBehaviour
{
    [SerializeField] float radiusLength = 2f;

    [SerializeField] PlayerController playerController;

    Interactable interactableObject;
    private void Awake()
    {
        playerController = GetComponent<PlayerController>();
        interactableObject = null;
    }
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        RaycastHit2D[] hits;
        hits = Physics2D.BoxCastAll(transform.position, Vector2.one, 360f, Vector2.zero, radiusLength);


        // check interactable object that has interact with player 
        // if it is not in detect range it will cancel interaction

        if (interactableObject != null)
        {
            //Debug.Log("1");
            Vector2 interactablePosition = new Vector2(interactableObject.transform.position.x,transform.position.y);
            float distance = Vector2.Distance(transform.position, interactablePosition );
            if (distance > radiusLength / 2)
            {
                //Debug.Log("2");
                interactableObject.CancelInteraction();
                //Debug.Log("3");
                interactableObject = null;
            }
        }

        //

        foreach (RaycastHit2D hit in hits)
        {



            if (hit.collider.GetComponent<Interactable>() != null)
            {
                interactableObject = hit.collider.GetComponent<Interactable>();
                //Debug.Log(interactableObject);
                //Debug.Log("1");
                interactableObject.EnableInteractKey();

                if (playerController.interact)
                {
                    //Debug.Log("2");
                    interactableObject.Interact(transform);
                    TurnOffInteractButton();
                }

            }
           

        }

    }

    public void TurnOffInteractButton()
    {

        playerController.interact = false;

    }



}
