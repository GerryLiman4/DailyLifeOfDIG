using Cinemachine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FourthDayScheme : MonoBehaviour
{
    [SerializeField] Renderer[] childrenObjects;
    [SerializeField] Narrator narrator;
    
    // Start is called before the first frame update
    void Start()
    {

        //ChangeEnabledInChildrenObject(false);
    }
    void Awake()
    {
        childrenObjects = gameObject.GetComponentsInChildren<Renderer>();

        ChangeEnabledInChildrenObject(false);
        narrator = GameObject.FindObjectOfType<Narrator>();
    }

    // Update is called once per frame
    void Update()
    {


    }

    public void CheckIfItIsFourthDay(int index)
    {
        if (narrator.currentDay == 4)
        {


                ChangeEnabledInChildrenObject(true);
            

        }
    }
    public void CheckIfItIsFourthDay(int index,CinemachineVirtualCamera cinemachineVirtualCamera)
    {
       // if (narrator.currentDay == 4)
        //{


            ChangeEnabledInChildrenObject(true, index,cinemachineVirtualCamera);



        //}
    }
    public void CheckIfItIsFourthDay(int index, CinemachineVirtualCamera cinemachineVirtualCamera,NPCController npcDud)
    {
        // if (narrator.currentDay == 4)
        //{


        ChangeEnabledInChildrenObject(true, index, cinemachineVirtualCamera,npcDud);



        //}
    }


    public void ChangeEnabledInChildrenObject(bool isEnabled,int index,CinemachineVirtualCamera cinemachineVirtualCamera)
    {
        string ending = "Ending" + index;
        Debug.Log("1 " + ending);
        foreach (Renderer childObject in childrenObjects)
        {
            Debug.Log("2 " + childObject.ToString());
            if (childObject.gameObject.name == ending)
            {
                Debug.Log("3 " + childObject.gameObject);
                childObject.enabled = isEnabled;
                Debug.Log("3 " + childObject.enabled);


                cinemachineVirtualCamera.Follow = childObject.gameObject.transform;

                return;



            }
        }
    }
    public void ChangeEnabledInChildrenObject(bool isEnabled, int index, CinemachineVirtualCamera cinemachineVirtualCamera, NPCController npcDud)
    {
        string ending = "Ending" + index;
        Debug.Log("1 " + ending);
        foreach (Renderer childObject in childrenObjects)
        {
            Debug.Log("2 " + childObject.ToString());
            if (childObject.gameObject.name == ending)
            {
                Debug.Log("3 " + childObject.gameObject);
                childObject.enabled = isEnabled;
                Debug.Log("3 " + childObject.enabled);


                cinemachineVirtualCamera.Follow = childObject.gameObject.transform;
                //npcDud.transform.position = childObject.transform.position;
                npcDud.GetComponent<Renderer>().enabled = true ;

                return;



            }
        }
    }
    public void ChangeEnabledInChildrenObject(bool isEnabled)
    {
        
        foreach (Renderer childObject in childrenObjects)
        {
                childObject.enabled = isEnabled;
            
        }
    }
    

}
