[System.Serializable]
public class TheEnding
{
    public string title;

    public TheEnding(string title)
    {
        this.title = title;
    }
    // Start is called before the first frame update

}