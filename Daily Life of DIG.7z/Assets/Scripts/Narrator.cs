using Cinemachine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Narrator : MonoBehaviour
{

    [SerializeField] public Dictionary<string, int> numberOfInteractions = new Dictionary<string, int>();
    [SerializeField] public OnInteractionEvent onInteraction;

    [SerializeField] public int currentDay = 1;

    [SerializeField] GameObject filter;
    [SerializeField] GameObject playerDIG;
    [SerializeField] List<NPCController> nPCControllers;


    [SerializeField] List<TheEnding> theEndings;
    [SerializeField] List<FourthDayScheme> fourthDaySchemes;
    [SerializeField] CinemachineVirtualCamera cinemachineVirtualCamera;
    [SerializeField] TextMeshProUGUI bubbleText;
    [SerializeField] PersistentObjectSpawner narratorPersistentObjectSpawner;





    [System.Serializable]
    public class OnInteractionEvent : UnityEvent<string>
    {

    }

    


    private void Awake()
    {
        if (theEndings.Count >= 1) {
            theEndings.Clear();
        }
        TheEnding ending1 = new TheEnding("Hanging Out");
        TheEnding ending2 = new TheEnding("Crashing Hour");
        TheEnding ending3 = new TheEnding("Not Working Time");
        TheEnding ending4 = new TheEnding("True Ending");
        TheEnding ending5 = new TheEnding("DIG");
        theEndings.Add(ending1);
        theEndings.Add(ending2);
        theEndings.Add(ending3);
        theEndings.Add(ending4);
        theEndings.Add(ending5);

    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }
        if (Input.GetKeyDown(KeyCode.R)) {
            StartCoroutine(BackToMainMenu());
        }
    }
    public IEnumerator BackToMainMenu()
    {
        FindPersistentObjectSpawner();  
        PersistentObjectSpawner.hasSpawned = false;

        yield return SceneManager.LoadSceneAsync(0);
        Destroy(gameObject);

    }

    // Update is called once per frame
    public void AddInteraction(Transform interactableObject)
    {
        string interactableObjectName = interactableObject.GetComponent<Interactable>().objectName;


        // kalo certain condition ga diitung
        if ((currentDay == 1 || currentDay == 2) && interactableObjectName == "DIGHouse") {
            return;
        }
        //  


        if (!numberOfInteractions.ContainsKey(interactableObjectName))
        {
           

            numberOfInteractions.Add(interactableObjectName, 1);
        }
        else
        {
            NPCController npcObject = interactableObject.GetComponent<NPCController>() ;
            
           
            if (npcObject != null)
            {
                // kalo yang nanya npc, dia bakal gadiitung kalo lewat dari hari pertama 
               

                    if (numberOfInteractions[interactableObjectName] < 16 && currentDay >= 2) {
                        return;
                    }
                
                //
            }

            int currentCount = numberOfInteractions[interactableObjectName];
            numberOfInteractions[interactableObjectName] = currentCount + 1;
        }



        Debug.Log(numberOfInteractions.Count);
        Debug.Log(numberOfInteractions[interactableObjectName]);

    }

    public void AssignDay() {
        currentDay += 1;
    }

    public void DoDayPreparation() {
        FindFilter();
        FindAllNPC();
        FindDIG();
        DoDirtyDeed();



    }

    public void DoDirtyDeed() {
        var colorTemp =
            filter.GetComponent<Image>().color;

      
        // color control
        if (currentDay == 2)
        {

            colorTemp.a = 0.05f;

        }
        else if (currentDay == 3)
        {
            colorTemp.a = 0.4f;
        }
        else if(currentDay == 4){

            
        }
        //

        //npc control
        if (currentDay >= 2  && currentDay != 4) {


            foreach (NPCController nPCController in nPCControllers)
            {


                //foreach (KeyValuePair<string,int> dick in numberOfInteractions) {
                //    Debug.Log(dick.Key + " : " + dick.Value);
                //} 


                if (numberOfInteractions.ContainsKey(nPCController.GetComponent<Interactable>().objectName))
                {
                    if (numberOfInteractions[nPCController.GetComponent<Interactable>().objectName] >= 16)
                    {
                        nPCController.gameObject.SetActive(false);
                    }
                }
            }



        }
        //


        //Check the ending
        if (currentDay == 4) {
            int endingDefault = 5;
            FindAllFourthDaySchemes();
            FindCinemachineVirtualCamera();
            FindTextBubble();
            


            


            //ending 1
            if (numberOfInteractions.ContainsKey("Tree")) {
                
                if (numberOfInteractions["Tree"] >= 5) {
                    endingDefault = 1;
                }
            }

            //

            // ending 2
            if (numberOfInteractions.ContainsKey("BusStop"))
            {

                if (numberOfInteractions["BusStop"] >= 5)
                {
                    endingDefault = 2;
                }
            }
            //

            // ending 3
            if (numberOfInteractions.ContainsKey("ClubBuilding"))
            {

                if (numberOfInteractions["ClubBuilding"] >= 8)
                {
                    endingDefault = 3;
                }
            }
            //

            // ending 4 
            NPCController npcDud = null;
            if (numberOfInteractions.ContainsKey("TheDud") && numberOfInteractions.ContainsKey("DIGHouse"))
            {

                if (numberOfInteractions["TheDud"] >= 16 && numberOfInteractions["DIGHouse"] >= 7)
                {
                    endingDefault = 4;
                    foreach (NPCController nPCController in nPCControllers)
                    {
                        if (nPCController.GetComponent<Interactable>().objectName == "TheDud")
                        {
                            npcDud = nPCController;
                            
                        }
                    }
                }
            }

            // Enable TextBubble and manipulate it
            if (endingDefault != 4)
            {
                bubbleText.text = "THE END : Ending " + endingDefault;
                
            }
            else {
                bubbleText.text = "THE END : TRUE ENDING " + endingDefault;
            }
            bubbleText.enabled = true;
            //
            
            
            // activate renderer for ending
            foreach (FourthDayScheme fourthDayScheme in fourthDaySchemes) {
                if (npcDud != null)
                {
                    Debug.Log(npcDud.name);
                    fourthDayScheme.CheckIfItIsFourthDay(endingDefault, cinemachineVirtualCamera,npcDud);
                    playerDIG.GetComponent<Renderer>().enabled = true;
                }
                else
                {
                    fourthDayScheme.CheckIfItIsFourthDay(endingDefault, cinemachineVirtualCamera);
                }
            }
            //
        }


        //



        filter.GetComponent<Image>().color = colorTemp;

    }

    public void FindFilter() {
        filter = GameObject.Find("Filter");
       
    }

    public void FindDIG() {
        playerDIG = GameObject.Find("DIG");
    }

    public void FindAllNPC() {
        nPCControllers = GameObject.FindObjectsOfType<NPCController>().ToList();
    }

    public void FindAllFourthDaySchemes() {
        fourthDaySchemes = GameObject.FindObjectsOfType<FourthDayScheme>().ToList();
    }

    public void FindCinemachineVirtualCamera() {

        cinemachineVirtualCamera = GameObject.FindObjectOfType<CinemachineVirtualCamera>();

    }

    public void FindTextBubble() {

        bubbleText = GameObject.FindObjectOfType<TextMeshProUGUI>();
        
    }
    public void FindPersistentObjectSpawner() {
        narratorPersistentObjectSpawner = GameObject.FindObjectOfType<PersistentObjectSpawner>();
        
    }
}
