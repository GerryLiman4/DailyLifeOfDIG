using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SecondDayScheme : MonoBehaviour
{
    [SerializeField] Renderer[] childrenObjects;
    [SerializeField] Narrator narrator;
    [SerializeField] GameObject theTrigger;
    // Start is called before the first frame update
    void Start()
    {
        
        
    }
    void Awake() {
        childrenObjects = gameObject.GetComponentsInChildren<Renderer>();

        ChangeEnabledInChildrenObject(false);
        narrator = GameObject.FindObjectOfType<Narrator>();
    }

    // Update is called once per frame
    void Update()
    {

        
    }

    public void CheckIfItIsSecondDay() {
        if (narrator.currentDay >= 2)       
        {


            if (narrator.numberOfInteractions.ContainsKey(theTrigger.GetComponent<Interactable>().objectName))
            {





                ChangeEnabledInChildrenObject(true);
            }

        }
    }


    public void ChangeEnabledInChildrenObject(bool isEnabled) {
        foreach (Renderer childObject in childrenObjects)
        {
            childObject.enabled = isEnabled;
        }
    }
}
